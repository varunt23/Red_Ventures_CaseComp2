import User from "/sorter.js";

var user = new User();
user.updateLanguage('en');
user.changeRating(0,10);
user.changeYear(0,2020);
user.updateProductionCompany('Pad Thai Pictures')
user.updateProductionCompany('Warner Bros. Pictures')
user.updateProductionCompany('Universal Pictures')






const loadPage = function(movies, shows) {
    const $root = $('.netflix')
    $root.append(`<div id="instructions">${user.preferencestats.netflix.count}</div>`);
    console.log()
        user.preferencestats.netflix.lists.forEach(element=> {
            let result = `<div id="instructions">${element.title}</div>`;
            $root.append(result)
        })
     
    // movies.forEach(element => {
    //     let result = `<div id="instructions">${element.title}</div>`;
    //     $root.append(result)
    // });
    //console.log("yayayayay")
    //console.log(movies)
    let result = `<div id="instructions">${movies}</div>`;
     $root.append(result)
     let ult = `<div id="instructions">djdejjedjj</div>`;
    $root.append(ult)
}

$(function() {
    //console.log("fefeffef")
    const movies =  axios({
        method: 'get',
        url: 'https://casecomp.konnectrv.io/movie?platform=hbo',
       });
    const http  = new  XMLHttpRequest();
    const url   = 'https://casecomp.konnectrv.io/show?platform=amazon_prime';
    const url1  = 'https://casecomp.konnectrv.io/movie?platform=hbo';
    const posters = 'http://theapache64.com/movie_db/search?keyword=Ironman';
    http.open('get', url);
    http.responseType = 'text';

    const shows =   axios({
       method: 'get',
       url: 'https://casecomp.konnectrv.io/show?platform=amazon_prime',
       });



    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open( "GET", url, false); // false for synchronous request
    xmlHttp.send( null );
    var obj = JSON.parse(xmlHttp.responseText);
    
    //console.log(obj[0].title);
    loadPage();

});
