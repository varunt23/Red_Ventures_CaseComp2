export default class User {
    constructor() {
        this.movielist = 'https://casecomp.konnectrv.io/movie';
        this.apmov = 'https://casecomp.konnectrv.io/movie?platfor';
        this.hbomov = 'https://casecomp.konnectrv.io/movie?platform=hbo';
        this.netmov = 'https://casecomp.konnectrv.io/movie?platform=netflix';
        this.showlist = 'https://casecomp.konnectrv.io/show';
        this.movprod = 'https://casecomp.konnectrv.io/production/movie';
        this.showprod = 'https://casecomp.konnectrv.io/production/show';
        this.showplat = 'https://casecomp.konnectrv.io/platform/movie';
        this.movplat = 'https://casecomp.konnectrv.io/platform/show';
        this.prodpref = [];
        this.langpref = ['en'];
        this.rating = [0,0];
        this.year = [0,0];
    }
    updateGenre(obj) {
        if(bool) {
            this.genreselect.push(obj);
            updatePreferences();
        } 
    }

    changeRating(lo, hi) {
        this.rating[0] = lo;
        this.rating[1] =hi;
        this.updatePreferences();
    }
    changeYear(lo, hi) {
        this.year[0] = lo;
        this.year[1] =hi;
        this.updatePreferences();
    }
    

    updateProductionCompany(obj) {
        this.prodpref.push(obj);
        this.updatePreferences();
    }

    updateLanguage(obj) {
        this.langpref.push(obj)
        this.updatePreferences();
    }

    stats(type) {
        //checking the production company
        let url;
        if(type ==1) {
            url = this.netmov;
        } else if(type ==2) {
            url = this.apmov;
        } else if(type ==3) {
            url = this.hbomov
        }
        //getting the http request using the 
        let xmlHttp = new XMLHttpRequest();
        xmlHttp.open( "GET", url, false); 
        xmlHttp.send( null );
        let movieobj = JSON.parse(xmlHttp.responseText)
        
        //applying the filters to the object from the request
        let list = movieobj.filter(a => this.checkprodcomp(a));
        if(Object.keys(list).length > 0) {
            //console.log(Object.keys(movieobj).length)
            list = list.filter(a => this.checklang(a));  
            if(Object.keys(list).length >0) {
                //console.log(Object.keys(movieobj).length)
                list = list.filter(a => this.rating[0] <= a.vote_average <= this.rating[1])
                if(Object.keys(list).length > 0) {
                    //console.log(Object.keys(movieobj).length)
                    list = list.filter(a => this.year[0] < a.release_date.split('-')[0] < this.year[1])
                    if(Object.keys(list).length > 0) {
                        //console.log(Object.keys(movieobj).length)
                        var count = Object.keys(list).length;
                        let avgrat = 3000/count;
                        return {
                            lists:list,
                            count:count,
                            avgrating:avgrat,
                        }
                    }
                }
            }
        } 

        //if there are eventually no items - go ahead and return no objects found
        return {
            lists:movieobj,
            count:0,
            avgrating:0,
        }
    }
    checklang(obj) {
        for(let i = 0; i < this.langpref.length; i ++) {
            if(this.langpref[i] == obj.original_language) {
                return true;
            }
        }
        return false;
    }
    checkprodcomp(obj) {
        let count = Object.keys(obj.production_companies).length;
        for(let i = 0; i < this.prodpref.length; i++) {
            for(let j = 0; j < count; j++ ) {
                if(obj.production_companies[j] == this.prodpref[i]){
                    return true;
                }
            }
        }
        return false;
    }
    updatePreferences() {
        this.preferencestats =  {
            netflix: {
                lists: this.stats(1).lists,
                count: this.stats(1).count,
                avgrating: this.stats(1).rating,
            },
            prime: {
                list: this.stats(2).list,
                count: this.stats(2).count,
                avgrating: this.stats(2).rating,
            },
            hbo: {
                list: this.stats(3).list,
                count: this.stats(3).count,
                avgrating: this.stats(3).rating,
            },
        };
    }
}




//console.log(Object.keys(list).length)
        //list = list.filter(a => this.checklang(a));  
        //console.log(Object.keys(list).length) 
        //list = list.filter(a => this.rating[0] <= a.vote_average <= this.rating[1])
        //if(Object.keys(list).length > 0){
        //    console.log(list[0].release_date.split('-')[0])
        //}
        //list = list.filter(a => this.year[0] < a.release_date.split('-')[0] < this.year[1])
        
    //need to figure out the rating system
        // const ratingTotal = list.reduce(function (a,b) {
        //     a.vote_average + b.vote_average
        // })
       
        //var count = Object.keys(list).length;
        //let avgrat = 3000/count;

        